# emotion_utils.py
